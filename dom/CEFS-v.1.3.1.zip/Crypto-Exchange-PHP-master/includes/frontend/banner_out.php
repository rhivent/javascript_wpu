        <header style="background:url([BANNER])center;">

        </header>