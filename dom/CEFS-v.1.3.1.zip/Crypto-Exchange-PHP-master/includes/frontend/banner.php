        <header style="background:url([BANNER])center;">
            <div class="box-menu">
                <p>Nome Nome</p>
                
                <ul> <a href="/dados"><li>Os smeus dados</li></a> <a href="/alterarpassword"><li>| Alterar password |</li></a> <a href="/logout"><li>Sair</li></a> </ul>
                
            </div>
        </header>